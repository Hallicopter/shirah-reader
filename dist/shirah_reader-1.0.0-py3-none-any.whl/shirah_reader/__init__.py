# __init__.py

# Version of the shirah-reader package
__version__ = "1.0.0"
